/*
 *	Advanced ray-tracer algorithm
 *	Emre Baris Coskun
 *	2018
 */

#ifndef __MEMORYMANAGER_H__
#define __MEMORYMANAGER_H__

class MemoryManager
{
public:
    MemoryManager();
    ~MemoryManager();

private:

};

#endif